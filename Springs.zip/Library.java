package com.setter;

import java.util.Set;
public class Library {
	private int id;
	private String name;
	private Set<String> books;
	public Library(int id, String name, Set<String> books) {
	super();
	this.id = id;
	this.name = name;
	this.books = books;
	}
	@Override
	public String toString() {
	return "Library [id=" + id + ", name=" + name + ", books=" + books + "]";
	}


}
