package com.setter;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class TestCollection {
	public static void main(String args[])
	{
	ApplicationContext con=new ClassPathXmlApplicationContext("springconfigure.xml");
	Object o=con.getBean("library");
	Library library=(Library) o;
	System.out.println(library);
	}
	}

