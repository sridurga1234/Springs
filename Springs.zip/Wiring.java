package com.setter;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.setter.Address;
import com.setter.EmployeeWiring;;


public class Wiring {
public static void main(String args[])
{
ApplicationContext context=new ClassPathXmlApplicationContext("WiringDemo.xml");
Object o=context.getBean("e");
EmployeeWiring e=(EmployeeWiring )o;
System.out.println(e);
}
}

