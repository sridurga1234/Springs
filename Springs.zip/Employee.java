package com.setter;

public class Employee extends person{
	int mobile;

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Employee [mobile=" + mobile + "]";
	}

	

}
