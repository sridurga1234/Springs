package com.setter;

public class EmployeeWiring {
int salary;
private Address addr;

public EmployeeWiring()
{

}
public EmployeeWiring(Address addr)
{
this.addr=addr;
}
public Address getAdd()
{
return addr;
}
public void setAdd(Address addr)
{
this.addr=addr;
}
public int getSalary() {
return salary;
}
public void setSalary(int salary) {
this.salary = salary;
}
@Override
public String toString() {
return "Employee [salary=" + salary + ", addr=" + addr + "]";
}
}
	


